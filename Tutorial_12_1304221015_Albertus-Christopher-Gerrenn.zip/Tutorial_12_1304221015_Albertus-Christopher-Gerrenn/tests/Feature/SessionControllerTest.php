<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;

class SessionControllerTest extends TestCase
{
    /** @test */
    public function it_can_store_session()
    {
        $response = $this->get('/set-session?email=gerrennyuwono@student.telkomuniversiy.ac.id');

        $response->assertStatus(200);
        $response->assertJson([
            'message' => 'Session email telah disimpan.',
            'email' => 'gerrennyuwono@student.telkomuniversiy.ac.id',
        ]);

        $this->assertEquals('gerrennyuwono@student.telkomuniversiy.ac.id', session('email'));
    }

    /** @test */
    public function it_can_get_session()
    {
        session(['email' => 'gerrennyuwono@student.telkomuniversiy.ac.id']);

        $response = $this->get('/get-session');

        $response->assertStatus(200);
        $response->assertJson([
            'email' => 'gerrennyuwono@student.telkomuniversiy.ac.id',
            'message' => 'Email ditemukan di session.',
        ]);
    }

    /** @test */
    public function it_can_delete_session()
    {
        session(['email' => 'gerrennyuwono@student.telkomuniversiy.ac.id']);

        $response = $this->get('/delete-session');

        $response->assertStatus(200);
        $response->assertJson([
            'message' => 'Semua session telah dihapus.',
        ]);

        $this->assertNull(session('email'));
    }
}