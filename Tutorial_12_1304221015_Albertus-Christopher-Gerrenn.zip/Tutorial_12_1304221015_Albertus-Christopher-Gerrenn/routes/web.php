<?php

use App\Http\Controllers\ProductController;
use App\Http\Controllers\SessionController;
use Illuminate\Support\Facades\Route;

// Mengarahkan rute awal langsung ke halaman daftar produk
Route::get('/', [ProductController::class, 'index']);

Route::resource('products', ProductController::class);

Route::get('/set-session', [SessionController::class, 'storeSession']);
Route::get('/get-session', [SessionController::class, 'getSession']);
Route::get('/delete-session', [SessionController::class, 'deleteSession']);
