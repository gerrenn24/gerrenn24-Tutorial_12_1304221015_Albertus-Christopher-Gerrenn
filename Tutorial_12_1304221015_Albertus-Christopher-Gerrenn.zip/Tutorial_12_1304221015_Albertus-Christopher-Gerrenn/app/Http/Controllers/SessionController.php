<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SessionController extends Controller
{
    // Menyimpan session dengan data dinamis
    public function storeSession(Request $request)
    {
        $email = $request->input('email', 'gerrennyuwono@student.telkomuniversiy.ac.id');
        session()->put('email', $email);
        return response()->json([
            'message' => 'Session email telah disimpan.',
            'email' => $email
        ]);
    }

    // Mengambil session dengan respons JSON
    public function getSession()
    {
        $email = session('email');
        return response()->json([
            'email' => $email,
            'message' => $email ? 'Email ditemukan di session.' : 'Session email tidak ditemukan.'
        ]);
    }

    // Menghapus session dengan konfirmasi
    public function deleteSession()
    {
        session()->flush();
        return response()->json([
            'message' => 'Semua session telah dihapus.'
        ]);
    }
}
