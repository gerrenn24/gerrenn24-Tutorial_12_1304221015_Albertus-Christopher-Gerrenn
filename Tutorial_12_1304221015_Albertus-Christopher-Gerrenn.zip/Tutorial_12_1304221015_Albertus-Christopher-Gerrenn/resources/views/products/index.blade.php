@extends('template')

@section('title', 'Produk')

@section('content')

<body class="container py-5">
  <div class="row justify-content-center">
    <div class="col-lg-10">
      @if(session('success'))
      <div class="alert alert-success alert-dismissible fade show" role="alert">
        {{ session('success') }}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>
      @endif

      <div class="card shadow-sm mb-4">
        <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
          <h5 class="mb-0">Daftar Produk</h5>
          <a href="{{ route('products.create') }}" class="btn btn-light btn-sm">Tambah Produk</a>
        </div>
        <div class="card-body">
          @if(session('msg'))
          <div class="alert alert-info">{{ session('msg') }}</div>
          @endif

          <div class="table-responsive">
            <table class="table table-hover">
              <thead class="table-dark">
                <tr>
                  <th>Nama Produk</th>
                  <th>Harga</th>
                  <th class="text-center">Aksi</th>
                </tr>
              </thead>
              <tbody>
                @forelse($products as $product)
                <tr>
                  <td>{{ $product->name }}</td>
                  <td>Rp {{ number_format($product->price, 0, ',', '.') }}</td>
                  <td class="text-center">
                    <a href="{{ route('products.edit', $product->id) }}" class="btn btn-outline-primary btn-sm me-2">Edit</a>
                    <form method="POST" action="{{ route('products.destroy', $product->id) }}" style="display:inline-block" onsubmit="return confirm('Yakin ingin menghapus produk ini?')">
                      @csrf
                      @method('DELETE')
                      <button class="btn btn-outline-danger btn-sm">Hapus</button>
                    </form>
                  </td>
                </tr>
                @empty
                <tr>
                  <td colspan="3" class="text-center">Tidak ada produk yang tersedia.</td>
                </tr>
                @endforelse
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
@endsection