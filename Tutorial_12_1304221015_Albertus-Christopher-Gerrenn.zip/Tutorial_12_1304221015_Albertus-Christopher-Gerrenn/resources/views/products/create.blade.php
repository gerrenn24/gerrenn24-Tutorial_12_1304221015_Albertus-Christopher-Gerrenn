@extends('template')

@section('title', 'Form Produk')

@section('content')

<body class="container py-5">
  <div class="row justify-content-center">
    <div class="col-md-8">
      <div class="card shadow-lg">
        <div class="card-header bg-dark text-white text-center">
          <h4 class="mb-0">Form Tambah Produk</h4>
        </div>
        <div class="card-body">
          <form method="POST" action="{{ route('products.store') }}">
            @csrf
            @if(isset($method) && $method === 'PUT')
            @method('PUT')
            @endif
            <div class="mb-4">
              <label for="name" class="form-label fw-bold">Nama Produk</label>
              <input type="text" name="name" id="name" class="form-control @error('name') is-invalid @enderror" value="{{ old('name', isset($product) ? $product->name : '') }}" placeholder="Masukkan nama produk">
              @error('name')
              <div class="invalid-feedback">{{ $message }}</div>
              @enderror
            </div>
            <div class="mb-4">
              <label for="price" class="form-label fw-bold">Harga Produk</label>
              <input type="number" name="price" id="price" class="form-control @error('price') is-invalid @enderror" value="{{ old('price', isset($product) ? $product->price : '') }}" placeholder="Masukkan harga produk">
              @error('price')
              <div class="invalid-feedback">{{ $message }}</div>
              @enderror
            </div>
            <div class="d-flex justify-content-between">
              <a href="{{ route('products.index') }}" class="btn btn-outline-secondary">Kembali</a>
              <button type="submit" class="btn btn-primary">Simpan</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

@endsection